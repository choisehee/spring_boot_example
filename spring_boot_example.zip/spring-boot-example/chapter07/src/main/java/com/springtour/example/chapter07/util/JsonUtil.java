package com.springtour.example.chapter07.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {

    public static final ObjectMapper objectMapper = new ObjectMapper();

}
