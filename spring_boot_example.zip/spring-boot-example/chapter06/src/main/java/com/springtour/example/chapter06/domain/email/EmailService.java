package com.springtour.example.chapter06.domain.email;

public interface EmailService {

    boolean sendEmail(EmailAddress emailAddress);
}
