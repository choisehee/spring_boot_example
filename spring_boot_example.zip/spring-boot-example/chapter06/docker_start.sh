docker run -d --rm -p 18080:18080 hotel-api:latest
