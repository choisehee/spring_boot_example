docker build --tag hotel-api:latest .
