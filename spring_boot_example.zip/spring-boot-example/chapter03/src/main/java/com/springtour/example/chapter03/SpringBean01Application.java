package com.springtour.example.chapter03;

import com.springtour.example.chapter03.domain.PriceUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;
import java.util.Locale;

@Slf4j
@SpringBootApplication
public class SpringBean01Application {

    public static void main(String[] args) {
        //스프링 부트 프레임워크의 기본 스프링 빈 컨테이너 구현체는 ConfigurableApplicotionContext이며 설정 포맷은 자바 클래스
        ConfigurableApplicationContext ctxt =
                SpringApplication.run(SpringBean01Application.class, args);

        PriceUnit defaultPriceUnit = ctxt.getBean("priceUnit", PriceUnit.class);
        log.info("Price #1 : {}", defaultPriceUnit.format(BigDecimal.valueOf(10.2)));
        defaultPriceUnit.validate();

        PriceUnit wonPriceUnit = ctxt.getBean("wonPriceUnit", PriceUnit.class);
        log.info("Price #2 : {}", wonPriceUnit.format(BigDecimal.valueOf(1000)));
        wonPriceUnit.validate();

        ctxt.close();
    }

    
    @Bean(name = "priceUnit")//스프링 빈 정의
    public PriceUnit dollarPriceUnit() {
        return new PriceUnit(Locale.US);
    }

    @Bean//속성 값을 설정하지 않으면 @Bean 애너테이션이 정의된 메서드 이름이 스프링 빈 이름이 된다
    public PriceUnit wonPriceUnit() {
        return new PriceUnit(Locale.KOREA);
    }
}
